import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, Alert } from 'react-native';
import * as bip39 from 'bip39';
import { ethers } from 'ethers';
import * as SecureStore from 'expo-secure-store';

export default function CreateWalletScreen({ navigation }) {
  const [mnemonic, setMnemonic] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  useEffect(() => { setMnemonic(bip39.generateMnemonic()); }, []);

  const handleCreate = async () => {
    if (pin.length < 6) return Alert.alert('Error', 'PIN must be at least 6 digits');
    if (pin !== confirmPin) return Alert.alert('Error', 'PINs do not match');
    setLoading(true);
    try {
      const hdNode = ethers.HDNodeWallet.fromPhrase(mnemonic);
      const ethWallet = hdNode.derivePath("m/44'/60'/0'/0/0");
      const encryptedJson = await new ethers.Wallet(ethWallet.privateKey).encrypt(pin);
      await SecureStore.setItemAsync('trustify_wallet', JSON.stringify({ address: ethWallet.address }));
      await SecureStore.setItemAsync('trustify_encrypted', encryptedJson);
      navigation.replace('Dashboard');
    } catch (e) { Alert.alert('Error', e.message); }
    setLoading(false);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 24 }}>
      {step === 1 ? (
        <>
          <Text style={styles.title}>Your Seed Phrase</Text>
          <Text style={styles.subtitle}>Write these 12 words down safely. Never share them.</Text>
          <View style={styles.mnemonicGrid}>
            {mnemonic.split(' ').map((word, i) => (
              <View key={i} style={styles.wordBox}>
                <Text style={styles.wordNum}>{i + 1}.</Text>
                <Text style={styles.wordText}>{word}</Text>
              </View>
            ))}
          </View>
          <TouchableOpacity style={styles.btnPrimary} onPress={() => setStep(2)}>
            <Text style={styles.btnText}>I've saved it → Continue</Text>
          </TouchableOpacity>
        </>
      ) : (
        <>
          <Text style={styles.title}>Set Your PIN</Text>
          <Text style={styles.subtitle}>This PIN encrypts your wallet on this device.</Text>
          <TextInput style={styles.input} placeholder="Enter PIN (min 6 digits)" placeholderTextColor="#a0aec0" secureTextEntry value={pin} onChangeText={setPin} keyboardType="numeric" maxLength={12} />
          <TextInput style={styles.input} placeholder="Confirm PIN" placeholderTextColor="#a0aec0" secureTextEntry value={confirmPin} onChangeText={setConfirmPin} keyboardType="numeric" maxLength={12} />
          <TouchableOpacity style={styles.btnPrimary} onPress={handleCreate} disabled={loading}>
            <Text style={styles.btnText}>{loading ? 'Creating...' : 'Create Wallet 🚀'}</Text>
          </TouchableOpacity>
        </>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  title: { fontSize: 24, fontWeight: '700', color: '#fff', marginBottom: 8 },
  subtitle: { color: '#a0aec0', marginBottom: 24, fontSize: 14 },
  mnemonicGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 24 },
  wordBox: { flexDirection: 'row', backgroundColor: '#0f3460', padding: 8, borderRadius: 8, width: '30%' },
  wordNum: { color: '#a0aec0', marginRight: 4, fontSize: 13 },
  wordText: { color: '#fff', fontSize: 13 },
  input: { backgroundColor: '#0f3460', borderWidth: 1, borderColor: '#2d3748', borderRadius: 10, padding: 14, color: '#fff', fontSize: 16, marginBottom: 16 },
  btnPrimary: { backgroundColor: '#e94560', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 8 },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});
