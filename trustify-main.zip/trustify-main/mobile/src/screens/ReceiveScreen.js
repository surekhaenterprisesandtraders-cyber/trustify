import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import * as SecureStore from 'expo-secure-store';
import * as Clipboard from 'expo-clipboard';

export default function ReceiveScreen() {
  const [address, setAddress] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    SecureStore.getItemAsync('trustify_wallet').then((stored) => {
      if (stored) setAddress(JSON.parse(stored).address);
    });
  }, []);

  const copyAddress = async () => {
    await Clipboard.setStringAsync(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Your Wallet Address</Text>
      <View style={styles.qrContainer}>
        {address ? <QRCode value={address} size={200} backgroundColor="white" /> : null}
      </View>
      <Text style={styles.address}>{address}</Text>
      <TouchableOpacity style={styles.btnPrimary} onPress={copyAddress}>
        <Text style={styles.btnText}>{copied ? '✅ Copied!' : '📋 Copy Address'}</Text>
      </TouchableOpacity>
      <Text style={styles.warning}>⚠️ Only send ERC20/BEP20 tokens to this address</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e', alignItems: 'center', padding: 24, paddingTop: 40 },
  title: { fontSize: 20, fontWeight: '700', color: '#fff', marginBottom: 32 },
  qrContainer: { padding: 16, backgroundColor: 'white', borderRadius: 16, marginBottom: 24 },
  address: { color: '#a0aec0', fontSize: 13, textAlign: 'center', marginBottom: 24, paddingHorizontal: 16 },
  btnPrimary: { backgroundColor: '#e94560', padding: 16, borderRadius: 12, alignItems: 'center', width: '100%', marginBottom: 16 },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  warning: { color: '#e94560', fontSize: 13, textAlign: 'center' },
});
