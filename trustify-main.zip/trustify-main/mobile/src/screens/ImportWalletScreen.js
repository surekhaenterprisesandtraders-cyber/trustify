import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, Alert } from 'react-native';
import * as bip39 from 'bip39';
import { ethers } from 'ethers';
import * as SecureStore from 'expo-secure-store';

export default function ImportWalletScreen({ navigation }) {
  const [mnemonicInput, setMnemonicInput] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [loading, setLoading] = useState(false);

  const handleImport = async () => {
    const trimmed = mnemonicInput.trim().toLowerCase();
    if (!bip39.validateMnemonic(trimmed)) return Alert.alert('Error', 'Invalid seed phrase');
    if (pin.length < 6) return Alert.alert('Error', 'PIN must be at least 6 digits');
    if (pin !== confirmPin) return Alert.alert('Error', 'PINs do not match');
    setLoading(true);
    try {
      const hdNode = ethers.HDNodeWallet.fromPhrase(trimmed);
      const ethWallet = hdNode.derivePath("m/44'/60'/0'/0/0");
      const encryptedJson = await new ethers.Wallet(ethWallet.privateKey).encrypt(pin);
      await SecureStore.setItemAsync('trustify_wallet', JSON.stringify({ address: ethWallet.address }));
      await SecureStore.setItemAsync('trustify_encrypted', encryptedJson);
      navigation.replace('Dashboard');
    } catch (e) { Alert.alert('Error', e.message); }
    setLoading(false);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 24 }}>
      <Text style={styles.title}>Import Wallet</Text>
      <Text style={styles.subtitle}>Enter your 12-word seed phrase to restore your wallet.</Text>
      <TextInput style={[styles.input, { height: 100, textAlignVertical: 'top' }]} placeholder="Enter your 12-word seed phrase..." placeholderTextColor="#a0aec0" multiline value={mnemonicInput} onChangeText={setMnemonicInput} />
      <TextInput style={styles.input} placeholder="Set PIN (min 6 digits)" placeholderTextColor="#a0aec0" secureTextEntry value={pin} onChangeText={setPin} keyboardType="numeric" maxLength={12} />
      <TextInput style={styles.input} placeholder="Confirm PIN" placeholderTextColor="#a0aec0" secureTextEntry value={confirmPin} onChangeText={setConfirmPin} keyboardType="numeric" maxLength={12} />
      <TouchableOpacity style={styles.btnPrimary} onPress={handleImport} disabled={loading}>
        <Text style={styles.btnText}>{loading ? 'Importing...' : 'Import Wallet'}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  title: { fontSize: 24, fontWeight: '700', color: '#fff', marginBottom: 8 },
  subtitle: { color: '#a0aec0', marginBottom: 24, fontSize: 14 },
  input: { backgroundColor: '#0f3460', borderWidth: 1, borderColor: '#2d3748', borderRadius: 10, padding: 14, color: '#fff', fontSize: 16, marginBottom: 16 },
  btnPrimary: { backgroundColor: '#e94560', padding: 16, borderRadius: 12, alignItems: 'center' },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});
