import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, ActivityIndicator } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import axios from 'axios';

const API_BASE = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:5000';

export default function TransactionsScreen() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchTxs(); }, []);

  const fetchTxs = async () => {
    const stored = await SecureStore.getItemAsync('trustify_wallet');
    if (!stored) return;
    const { address } = JSON.parse(stored);
    try {
      const { data } = await axios.get(`${API_BASE}/api/transactions/ethereum/${address}`);
      if (data.success) setTransactions(data.transactions);
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  if (loading) return <View style={styles.center}><ActivityIndicator color="#e94560" size="large" /></View>;

  return (
    <FlatList
      style={styles.container}
      data={transactions}
      keyExtractor={(item) => item.hash}
      ListEmptyComponent={<Text style={styles.empty}>No transactions found</Text>}
      renderItem={({ item }) => (
        <View style={styles.txCard}>
          <View style={styles.txRow}>
            <Text style={{ color: item.status === 'confirmed' ? '#00d4aa' : '#e94560', fontWeight: '600' }}>
              {item.status === 'confirmed' ? '✅ Confirmed' : '❌ Failed'}
            </Text>
            <Text style={styles.txDate}>{new Date(item.timestamp).toLocaleDateString()}</Text>
          </View>
          <Text style={styles.txAmount}>{item.amount} {item.symbol}</Text>
          <Text style={styles.txAddress}>To: {item.to?.slice(0, 20)}...</Text>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e', padding: 16 },
  center: { flex: 1, backgroundColor: '#1a1a2e', alignItems: 'center', justifyContent: 'center' },
  empty: { color: '#a0aec0', textAlign: 'center', marginTop: 48 },
  txCard: { backgroundColor: '#16213e', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#2d3748' },
  txRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  txDate: { color: '#a0aec0', fontSize: 13 },
  txAmount: { color: '#fff', fontWeight: '600', fontSize: 16, marginBottom: 4 },
  txAddress: { color: '#a0aec0', fontSize: 12 },
});
