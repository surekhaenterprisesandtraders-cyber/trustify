import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, Alert } from 'react-native';
import { ethers } from 'ethers';
import * as SecureStore from 'expo-secure-store';

const RPC_URLS = { ethereum: 'https://eth.llamarpc.com', bsc: 'https://bsc-dataseed.binance.org' };
const USDT_CONTRACTS = { ethereum: '0xdAC17F958D2ee523a2206206994597C13D831ec7', bsc: '0x55d398326f99059fF775485246999027B3197955' };
const ERC20_ABI = ['function transfer(address to, uint256 amount) returns (bool)', 'function decimals() view returns (uint8)'];

export default function SendScreen({ navigation }) {
  const [toAddress, setToAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [coin, setCoin] = useState('ETH');
  const [network, setNetwork] = useState('ethereum');
  const [pin, setPin] = useState('');
  const [loading, setLoading] = useState(false);
  const [txHash, setTxHash] = useState('');

  const handleSend = async () => {
    if (!toAddress || !amount || !pin) return Alert.alert('Error', 'Fill all fields');
    setLoading(true);
    try {
      const encryptedJson = await SecureStore.getItemAsync('trustify_encrypted');
      const wallet = await ethers.Wallet.fromEncryptedJson(encryptedJson, pin);
      const provider = new ethers.JsonRpcProvider(RPC_URLS[network]);
      const signer = wallet.connect(provider);
      let hash;
      if (coin === 'USDT') {
        const contract = new ethers.Contract(USDT_CONTRACTS[network], ERC20_ABI, signer);
        const decimals = await contract.decimals();
        const tx = await contract.transfer(toAddress, ethers.parseUnits(amount, decimals));
        hash = tx.hash;
      } else {
        const tx = await signer.sendTransaction({ to: toAddress, value: ethers.parseEther(amount) });
        hash = tx.hash;
      }
      setTxHash(hash);
    } catch (e) { Alert.alert('Transaction Failed', e.message); }
    setLoading(false);
  };

  if (txHash) return (
    <View style={[styles.container, { alignItems: 'center', justifyContent: 'center', padding: 24 }]}>
      <Text style={{ fontSize: 64 }}>✅</Text>
      <Text style={styles.title}>Transaction Sent!</Text>
      <Text style={{ color: '#a0aec0', fontSize: 12, textAlign: 'center', margin: 16 }}>{txHash}</Text>
      <TouchableOpacity style={styles.btnPrimary} onPress={() => navigation.navigate('Dashboard')}>
        <Text style={styles.btnText}>Back to Dashboard</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 24 }}>
      <Text style={styles.label}>Network</Text>
      <View style={styles.row}>
        {['ethereum', 'bsc'].map((n) => (
          <TouchableOpacity key={n} style={[styles.chip, network === n && styles.chipActive]} onPress={() => setNetwork(n)}>
            <Text style={{ color: '#fff', fontSize: 13 }}>{n === 'ethereum' ? 'ETH' : 'BSC'}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <Text style={styles.label}>Coin</Text>
      <View style={styles.row}>
        {['ETH', 'BNB', 'USDT'].map((c) => (
          <TouchableOpacity key={c} style={[styles.chip, coin === c && styles.chipActive]} onPress={() => setCoin(c)}>
            <Text style={{ color: '#fff', fontSize: 13 }}>{c}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <TextInput style={styles.input} placeholder="Recipient Address" placeholderTextColor="#a0aec0" value={toAddress} onChangeText={setToAddress} />
      <TextInput style={styles.input} placeholder="Amount" placeholderTextColor="#a0aec0" keyboardType="decimal-pad" value={amount} onChangeText={setAmount} />
      <TextInput style={styles.input} placeholder="Enter PIN to confirm" placeholderTextColor="#a0aec0" secureTextEntry value={pin} onChangeText={setPin} />
      <TouchableOpacity style={styles.btnPrimary} onPress={handleSend} disabled={loading}>
        <Text style={styles.btnText}>{loading ? 'Sending...' : `Send ${coin}`}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  title: { fontSize: 24, fontWeight: '700', color: '#fff', marginBottom: 8 },
  label: { color: '#a0aec0', marginBottom: 8, marginTop: 16 },
  row: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  chip: { paddingHorizontal: 16, paddingVertical: 8, backgroundColor: '#0f3460', borderRadius: 20, borderWidth: 1, borderColor: '#2d3748' },
  chipActive: { borderColor: '#e94560', backgroundColor: 'rgba(233,69,96,0.2)' },
  input: { backgroundColor: '#0f3460', borderWidth: 1, borderColor: '#2d3748', borderRadius: 10, padding: 14, color: '#fff', fontSize: 16, marginBottom: 16 },
  btnPrimary: { backgroundColor: '#e94560', padding: 16, borderRadius: 12, alignItems: 'center', marginTop: 8 },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});
