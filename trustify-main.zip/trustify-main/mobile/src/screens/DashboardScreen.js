import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, RefreshControl } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import { ethers } from 'ethers';
import axios from 'axios';

const API_BASE = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:5000';
const RPC_ETH = 'https://eth.llamarpc.com';
const USDT_ERC20 = '0xdAC17F958D2ee523a2206206994597C13D831ec7';
const ERC20_ABI = ['function balanceOf(address) view returns (uint256)', 'function decimals() view returns (uint8)'];

export default function DashboardScreen({ navigation }) {
  const [address, setAddress] = useState('');
  const [balances, setBalances] = useState({ ETH: '0.0000', USDT: '0.00' });
  const [prices, setPrices] = useState({});
  const [totalUSD, setTotalUSD] = useState('0.00');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadWallet(); }, []);

  const loadWallet = async () => {
    const stored = await SecureStore.getItemAsync('trustify_wallet');
    if (stored) {
      const { address: addr } = JSON.parse(stored);
      setAddress(addr);
      fetchData(addr);
    }
  };

  const fetchData = async (addr) => {
    try {
      const { data } = await axios.get(`${API_BASE}/api/prices`);
      if (data.success) setPrices(data.prices);
      const provider = new ethers.JsonRpcProvider(RPC_ETH);
      const ethBal = await provider.getBalance(addr);
      const ethBalance = parseFloat(ethers.formatEther(ethBal)).toFixed(4);
      const contract = new ethers.Contract(USDT_ERC20, ERC20_ABI, provider);
      const [usdtBal, dec] = await Promise.all([contract.balanceOf(addr), contract.decimals()]);
      const usdtBalance = parseFloat(ethers.formatUnits(usdtBal, dec)).toFixed(2);
      setBalances({ ETH: ethBalance, USDT: usdtBalance });
      const p = data.prices || {};
      setTotalUSD((parseFloat(ethBalance) * (p.ETH?.usd || 0) + parseFloat(usdtBalance)).toFixed(2));
    } catch (e) { console.error(e); }
  };

  const onRefresh = async () => { setRefreshing(true); await loadWallet(); setRefreshing(false); };

  return (
    <ScrollView style={styles.container} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#e94560" />}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Trustify</Text>
      </View>
      <View style={styles.balanceCard}>
        <Text style={styles.balanceLabel}>Total Balance</Text>
        <Text style={styles.balanceAmount}>${totalUSD}</Text>
        <Text style={styles.addressText}>{address ? `${address.slice(0, 6)}...${address.slice(-4)}` : ''}</Text>
      </View>
      <View style={styles.actions}>
        {[{ label: 'Send', icon: '↑', screen: 'Send' }, { label: 'Receive', icon: '↓', screen: 'Receive' }, { label: 'History', icon: '📋', screen: 'Transactions' }].map((a) => (
          <TouchableOpacity key={a.label} style={styles.actionBtn} onPress={() => navigation.navigate(a.screen)}>
            <Text style={styles.actionIcon}>{a.icon}</Text>
            <Text style={styles.actionLabel}>{a.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <Text style={styles.sectionTitle}>Assets</Text>
      {[{ symbol: 'ETH', name: 'Ethereum', icon: '⟠' }, { symbol: 'USDT', name: 'Tether USD', icon: '💵' }].map((coin) => (
        <View key={coin.symbol} style={styles.coinCard}>
          <Text style={styles.coinIcon}>{coin.icon}</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.coinSymbol}>{coin.symbol}</Text>
            <Text style={styles.coinName}>{coin.name}</Text>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={styles.coinBalance}>{balances[coin.symbol] || '0.00'}</Text>
            <Text style={styles.coinUSD}>${prices[coin.symbol] ? (parseFloat(balances[coin.symbol] || 0) * prices[coin.symbol].usd).toFixed(2) : '0.00'}</Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  header: { flexDirection: 'row', justifyContent: 'space-between', padding: 24, paddingTop: 48 },
  headerTitle: { fontSize: 24, fontWeight: '700', color: '#fff' },
  balanceCard: { margin: 16, padding: 24, backgroundColor: '#16213e', borderRadius: 16, alignItems: 'center', borderWidth: 1, borderColor: '#2d3748' },
  balanceLabel: { color: '#a0aec0', marginBottom: 8 },
  balanceAmount: { fontSize: 36, fontWeight: '700', color: '#fff', marginBottom: 8 },
  addressText: { color: '#a0aec0', fontSize: 13 },
  actions: { flexDirection: 'row', margin: 16, gap: 12 },
  actionBtn: { flex: 1, backgroundColor: '#16213e', padding: 16, borderRadius: 12, alignItems: 'center', borderWidth: 1, borderColor: '#2d3748' },
  actionIcon: { fontSize: 24, marginBottom: 4 },
  actionLabel: { color: '#fff', fontSize: 13, fontWeight: '600' },
  sectionTitle: { color: '#a0aec0', fontSize: 16, fontWeight: '600', marginHorizontal: 16, marginBottom: 12 },
  coinCard: { flexDirection: 'row', alignItems: 'center', margin: 8, marginHorizontal: 16, padding: 16, backgroundColor: '#16213e', borderRadius: 12, borderWidth: 1, borderColor: '#2d3748' },
  coinIcon: { fontSize: 32, marginRight: 12 },
  coinSymbol: { color: '#fff', fontWeight: '600', fontSize: 16 },
  coinName: { color: '#a0aec0', fontSize: 13 },
  coinBalance: { color: '#fff', fontWeight: '600' },
  coinUSD: { color: '#a0aec0', fontSize: 13 },
});
