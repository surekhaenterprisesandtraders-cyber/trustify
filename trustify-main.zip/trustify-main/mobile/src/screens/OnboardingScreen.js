import React, { useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import * as SecureStore from 'expo-secure-store';

export default function OnboardingScreen({ navigation }) {
  useEffect(() => { checkWallet(); }, []);

  const checkWallet = async () => {
    const wallet = await SecureStore.getItemAsync('trustify_wallet');
    if (wallet) navigation.replace('Dashboard');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.icon}>🔐</Text>
      <Text style={styles.title}>Trustify</Text>
      <Text style={styles.subtitle}>Your non-custodial crypto wallet</Text>
      <TouchableOpacity style={styles.btnPrimary} onPress={() => navigation.navigate('CreateWallet')}>
        <Text style={styles.btnText}>Create New Wallet</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.btnSecondary} onPress={() => navigation.navigate('ImportWallet')}>
        <Text style={styles.btnText}>Import Existing Wallet</Text>
      </TouchableOpacity>
      <Text style={styles.note}>🔒 Your keys, your crypto. We never store your private keys.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e', alignItems: 'center', justifyContent: 'center', padding: 24 },
  icon: { fontSize: 64, marginBottom: 16 },
  title: { fontSize: 32, fontWeight: '700', color: '#fff', marginBottom: 8 },
  subtitle: { fontSize: 16, color: '#a0aec0', marginBottom: 48, textAlign: 'center' },
  btnPrimary: { width: '100%', backgroundColor: '#e94560', padding: 16, borderRadius: 12, alignItems: 'center', marginBottom: 12 },
  btnSecondary: { width: '100%', backgroundColor: '#0f3460', padding: 16, borderRadius: 12, alignItems: 'center', marginBottom: 32, borderWidth: 1, borderColor: '#2d3748' },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  note: { color: '#a0aec0', fontSize: 13, textAlign: 'center' },
});
