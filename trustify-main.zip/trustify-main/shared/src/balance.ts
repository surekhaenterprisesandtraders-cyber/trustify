import { ethers } from 'ethers';
import { TokenBalance } from './types';

const RPC_URLS: Record<string, string> = {
  ethereum: 'https://eth.llamarpc.com',
  bsc: 'https://bsc-dataseed.binance.org',
};

const ERC20_ABI = [
  'function balanceOf(address owner) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
];

const USDT_CONTRACTS: Record<string, string> = {
  ethereum: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
  bsc: '0x55d398326f99059fF775485246999027B3197955',
};

export async function getNativeBalance(address: string, network: 'ethereum' | 'bsc'): Promise<TokenBalance> {
  const provider = new ethers.JsonRpcProvider(RPC_URLS[network]);
  const balance = await provider.getBalance(address);
  const symbol = network === 'ethereum' ? 'ETH' : 'BNB';
  return { symbol, balance: ethers.formatEther(balance), network };
}

export async function getUSDTBalance(address: string, network: 'ethereum' | 'bsc'): Promise<TokenBalance> {
  const provider = new ethers.JsonRpcProvider(RPC_URLS[network]);
  const contract = new ethers.Contract(USDT_CONTRACTS[network], ERC20_ABI, provider);
  const [balance, decimals] = await Promise.all([contract.balanceOf(address), contract.decimals()]);
  return {
    symbol: 'USDT',
    balance: ethers.formatUnits(balance, decimals),
    network,
    contractAddress: USDT_CONTRACTS[network],
  };
}

export async function getTronBalances(address: string): Promise<TokenBalance[]> {
  const TronWeb = (await import('tronweb')).default;
  const tronWeb = new TronWeb({ fullHost: 'https://api.trongrid.io' });
  const trxBalance = await tronWeb.trx.getBalance(address);
  const trx: TokenBalance = { symbol: 'TRX', balance: (trxBalance / 1_000_000).toString(), network: 'tron' };
  const USDT_TRC20 = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
  const contract = await tronWeb.contract().at(USDT_TRC20);
  const usdtRaw = await contract.balanceOf(address).call();
  const usdt: TokenBalance = {
    symbol: 'USDT',
    balance: (Number(usdtRaw) / 1_000_000).toString(),
    network: 'tron',
    contractAddress: USDT_TRC20,
  };
  return [trx, usdt];
}
