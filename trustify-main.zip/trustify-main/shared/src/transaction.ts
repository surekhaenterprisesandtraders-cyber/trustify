import { ethers } from 'ethers';

const RPC_URLS: Record<string, string> = {
  ethereum: 'https://eth.llamarpc.com',
  bsc: 'https://bsc-dataseed.binance.org',
};

const USDT_CONTRACTS: Record<string, string> = {
  ethereum: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
  bsc: '0x55d398326f99059fF775485246999027B3197955',
};

const ERC20_ABI = [
  'function transfer(address to, uint256 amount) returns (bool)',
  'function decimals() view returns (uint8)',
];

export async function sendNative(privateKey: string, toAddress: string, amount: string, network: 'ethereum' | 'bsc'): Promise<string> {
  const provider = new ethers.JsonRpcProvider(RPC_URLS[network]);
  const wallet = new ethers.Wallet(privateKey, provider);
  const tx = await wallet.sendTransaction({ to: toAddress, value: ethers.parseEther(amount) });
  return tx.hash;
}

export async function sendUSDT(privateKey: string, toAddress: string, amount: string, network: 'ethereum' | 'bsc'): Promise<string> {
  const provider = new ethers.JsonRpcProvider(RPC_URLS[network]);
  const wallet = new ethers.Wallet(privateKey, provider);
  const contract = new ethers.Contract(USDT_CONTRACTS[network], ERC20_ABI, wallet);
  const decimals = await contract.decimals();
  const tx = await contract.transfer(toAddress, ethers.parseUnits(amount, decimals));
  return tx.hash;
}

export async function sendTRX(privateKey: string, toAddress: string, amount: string): Promise<string> {
  const TronWeb = (await import('tronweb')).default;
  const tronWeb = new TronWeb({ fullHost: 'https://api.trongrid.io', privateKey });
  const amountSun = Math.floor(parseFloat(amount) * 1_000_000);
  const tx = await tronWeb.trx.sendTransaction(toAddress, amountSun);
  return tx.txid;
}

export async function sendTRC20USDT(privateKey: string, toAddress: string, amount: string): Promise<string> {
  const TronWeb = (await import('tronweb')).default;
  const tronWeb = new TronWeb({ fullHost: 'https://api.trongrid.io', privateKey });
  const USDT_TRC20 = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
  const contract = await tronWeb.contract().at(USDT_TRC20);
  const amountUnits = Math.floor(parseFloat(amount) * 1_000_000);
  const tx = await contract.transfer(toAddress, amountUnits).send();
  return tx;
}
