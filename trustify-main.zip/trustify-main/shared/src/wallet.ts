import * as bip39 from 'bip39';
import { ethers } from 'ethers';
import { WalletAccount } from './types';

// Generate new mnemonic seed phrase (12 words)
export function generateMnemonic(): string {
  return bip39.generateMnemonic();
}

// Validate mnemonic
export function validateMnemonic(mnemonic: string): boolean {
  return bip39.validateMnemonic(mnemonic);
}

// Derive ETH / BNB wallet from mnemonic
export function deriveEVMWallet(
  mnemonic: string,
  network: 'ethereum' | 'bsc',
  index: number = 0
): WalletAccount {
  const hdNode = ethers.HDNodeWallet.fromPhrase(mnemonic);
  const child = hdNode.derivePath(`m/44'/60'/0'/0/${index}`);
  return {
    address: child.address,
    privateKey: child.privateKey,
    mnemonic,
    network,
  };
}

// Derive TRX wallet from mnemonic
export async function deriveTronWallet(
  mnemonic: string,
  index: number = 0
): Promise<WalletAccount> {
  const seed = await bip39.mnemonicToSeed(mnemonic);
  const HDKey = (await import('hdkey')).default;
  const root = HDKey.fromMasterSeed(seed);
  const child = root.derive(`m/44'/195'/0'/0/${index}`);
  const privateKeyHex = child.privateKey!.toString('hex');
  const TronWeb = (await import('tronweb')).default;
  const tronWeb = new TronWeb({ fullHost: 'https://api.trongrid.io' });
  const address = tronWeb.address.fromPrivateKey(privateKeyHex);
  return {
    address,
    privateKey: privateKeyHex,
    mnemonic,
    network: 'tron',
  };
}

// Encrypt private key with PIN
export async function encryptPrivateKey(privateKey: string, pin: string): Promise<string> {
  const wallet = new ethers.Wallet(privateKey);
  return wallet.encrypt(pin);
}

// Decrypt private key with PIN
export async function decryptPrivateKey(encryptedJson: string, pin: string): Promise<string> {
  const wallet = await ethers.Wallet.fromEncryptedJson(encryptedJson, pin);
  return wallet.privateKey;
}
