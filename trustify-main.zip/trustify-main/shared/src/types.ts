export type NetworkType = 'ethereum' | 'bsc' | 'tron';

export interface WalletAccount {
  address: string;
  privateKey: string;
  mnemonic?: string;
  network: NetworkType;
}

export interface TokenBalance {
  symbol: string;
  balance: string;
  usdValue?: number;
  network: NetworkType;
  contractAddress?: string;
}

export interface Transaction {
  hash: string;
  from: string;
  to: string;
  amount: string;
  symbol: string;
  network: NetworkType;
  timestamp: number;
  status: 'pending' | 'confirmed' | 'failed';
  fee?: string;
}

export interface CoinPrice {
  symbol: string;
  usd: number;
  change24h: number;
}
