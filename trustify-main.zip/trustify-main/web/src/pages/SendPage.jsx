import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ethers } from 'ethers';
import { useWalletStore } from '../store/walletStore';

const RPC_URLS = { ethereum: 'https://eth.llamarpc.com', bsc: 'https://bsc-dataseed.binance.org' };
const USDT_CONTRACTS = { ethereum: '0xdAC17F958D2ee523a2206206994597C13D831ec7', bsc: '0x55d398326f99059fF775485246999027B3197955' };
const ERC20_ABI = ['function transfer(address to, uint256 amount) returns (bool)', 'function decimals() view returns (uint8)'];

export default function SendPage() {
  const navigate = useNavigate();
  const { encryptedMnemonic, balances } = useWalletStore();
  const [toAddress, setToAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [coin, setCoin] = useState('ETH');
  const [network, setNetwork] = useState('ethereum');
  const [pin, setPin] = useState('');
  const [loading, setLoading] = useState(false);
  const [txHash, setTxHash] = useState('');

  const handleSend = async () => {
    if (!toAddress || !amount || !pin) return alert('Fill all fields');
    setLoading(true);
    try {
      const wallet = await ethers.Wallet.fromEncryptedJson(encryptedMnemonic, pin);
      const provider = new ethers.JsonRpcProvider(RPC_URLS[network]);
      const signer = wallet.connect(provider);
      let hash;
      if (coin === 'USDT') {
        const contract = new ethers.Contract(USDT_CONTRACTS[network], ERC20_ABI, signer);
        const decimals = await contract.decimals();
        const tx = await contract.transfer(toAddress, ethers.parseUnits(amount, decimals));
        hash = tx.hash;
      } else {
        const tx = await signer.sendTransaction({ to: toAddress, value: ethers.parseEther(amount) });
        hash = tx.hash;
      }
      setTxHash(hash);
    } catch (e) { alert('Transaction failed: ' + e.message); }
    setLoading(false);
  };

  if (txHash) return (
    <div className="container" style={{ paddingTop: '80px', textAlign: 'center' }}>
      <div style={{ fontSize: '64px', marginBottom: '16px' }}>✅</div>
      <h2 style={{ marginBottom: '8px' }}>Transaction Sent!</h2>
      <p style={{ color: 'var(--text-secondary)', fontSize: '13px', wordBreak: 'break-all', marginBottom: '24px' }}>TX: {txHash}</p>
      <button className="btn btn-primary" onClick={() => navigate('/dashboard')}>Back to Dashboard</button>
    </div>
  );

  return (
    <div className="container" style={{ paddingTop: '40px' }}>
      <button onClick={() => navigate('/dashboard')} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer', marginBottom: '24px', fontSize: '16px' }}>← Back</button>
      <h2 style={{ marginBottom: '24px' }}>Send Crypto</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <select value={network} onChange={(e) => setNetwork(e.target.value)}
          style={{ padding: '12px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '10px', color: 'var(--text-primary)', fontSize: '16px' }}>
          <option value="ethereum">Ethereum (ERC20)</option>
          <option value="bsc">BSC (BEP20)</option>
        </select>
        <select value={coin} onChange={(e) => setCoin(e.target.value)}
          style={{ padding: '12px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '10px', color: 'var(--text-primary)', fontSize: '16px' }}>
          <option value="ETH">ETH</option>
          <option value="BNB">BNB</option>
          <option value="USDT">USDT</option>
        </select>
        <input placeholder="Recipient Address (0x...)" value={toAddress} onChange={(e) => setToAddress(e.target.value)} />
        <input type="number" placeholder="Amount" value={amount} onChange={(e) => setAmount(e.target.value)} />
        <input type="password" placeholder="Enter PIN to confirm" value={pin} onChange={(e) => setPin(e.target.value)} />
        <p style={{ color: 'var(--text-secondary)', fontSize: '13px' }}>Balance: {balances[coin] || '0'} {coin}</p>
        <button className="btn btn-primary" onClick={handleSend} disabled={loading}>
          {loading ? 'Sending...' : `Send ${coin}`}
        </button>
      </div>
    </div>
  );
}
