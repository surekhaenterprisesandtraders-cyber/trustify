import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import * as bip39 from 'bip39';
import { ethers } from 'ethers';
import { useWalletStore } from '../store/walletStore';

export default function CreateWalletPage() {
  const navigate = useNavigate();
  const { setWallet } = useWalletStore();
  const [mnemonic, setMnemonic] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [step, setStep] = useState(1);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => { setMnemonic(bip39.generateMnemonic()); }, []);

  const copyMnemonic = () => {
    navigator.clipboard.writeText(mnemonic);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCreateWallet = async () => {
    if (pin.length < 6) return alert('PIN must be at least 6 digits');
    if (pin !== confirmPin) return alert('PINs do not match');
    setLoading(true);
    try {
      const hdNode = ethers.HDNodeWallet.fromPhrase(mnemonic);
      const ethWallet = hdNode.derivePath("m/44'/60'/0'/0/0");
      const tempWallet = new ethers.Wallet(ethWallet.privateKey);
      const encryptedMnemonic = await tempWallet.encrypt(pin);
      setWallet({ ethereum: ethWallet.address, bsc: ethWallet.address }, encryptedMnemonic);
      navigate('/dashboard');
    } catch (e) { alert('Error: ' + e.message); }
    setLoading(false);
  };

  return (
    <div className="container" style={{ paddingTop: '40px' }}>
      <button onClick={() => step === 1 ? navigate('/') : setStep(1)}
        style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer', marginBottom: '24px', fontSize: '16px' }}>
        ← Back
      </button>
      {step === 1 && (
        <>
          <h2 style={{ marginBottom: '8px' }}>Your Seed Phrase</h2>
          <p style={{ color: 'var(--text-secondary)', marginBottom: '24px', fontSize: '14px' }}>
            Write these 12 words down and keep them safe. Never share them.
          </p>
          <div className="card" style={{ marginBottom: '24px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
              {mnemonic.split(' ').map((word, i) => (
                <div key={i} style={{ background: 'var(--bg-card)', padding: '8px 12px', borderRadius: '8px', fontSize: '14px' }}>
                  <span style={{ color: 'var(--text-secondary)', marginRight: '6px' }}>{i + 1}.</span>{word}
                </div>
              ))}
            </div>
          </div>
          <button className="btn btn-secondary" onClick={copyMnemonic} style={{ marginBottom: '12px' }}>
            {copied ? '✅ Copied!' : '📋 Copy Seed Phrase'}
          </button>
          <button className="btn btn-primary" onClick={() => setStep(2)}>I've saved it → Continue</button>
        </>
      )}
      {step === 2 && (
        <>
          <h2 style={{ marginBottom: '8px' }}>Set Your PIN</h2>
          <p style={{ color: 'var(--text-secondary)', marginBottom: '24px', fontSize: '14px' }}>This PIN encrypts your wallet on this device.</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <input type="password" placeholder="Enter PIN (min 6 digits)" value={pin} onChange={(e) => setPin(e.target.value)} maxLength={12} />
            <input type="password" placeholder="Confirm PIN" value={confirmPin} onChange={(e) => setConfirmPin(e.target.value)} maxLength={12} />
            <button className="btn btn-primary" onClick={handleCreateWallet} disabled={loading}>
              {loading ? 'Creating Wallet...' : 'Create Wallet 🚀'}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
