import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useWalletStore } from '../store/walletStore';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000';

export default function TransactionsPage() {
  const navigate = useNavigate();
  const { wallets } = useWalletStore();
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [network, setNetwork] = useState('ethereum');

  useEffect(() => { fetchTransactions(); }, [network]);

  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const address = wallets[network] || wallets.ethereum;
      const { data } = await axios.get(`${API_BASE}/api/transactions/${network}/${address}`);
      if (data.success) setTransactions(data.transactions);
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  return (
    <div className="container" style={{ paddingTop: '40px', paddingBottom: '40px' }}>
      <button onClick={() => navigate('/dashboard')} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer', marginBottom: '24px', fontSize: '16px' }}>← Back</button>
      <h2 style={{ marginBottom: '16px' }}>Transaction History</h2>
      <select value={network} onChange={(e) => setNetwork(e.target.value)}
        style={{ width: '100%', padding: '12px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '10px', color: 'var(--text-primary)', fontSize: '16px', marginBottom: '24px' }}>
        <option value="ethereum">Ethereum</option>
        <option value="bsc">BSC</option>
        <option value="tron">Tron</option>
      </select>
      {loading ? (
        <p style={{ textAlign: 'center', color: 'var(--text-secondary)' }}>Loading...</p>
      ) : transactions.length === 0 ? (
        <p style={{ textAlign: 'center', color: 'var(--text-secondary)' }}>No transactions found</p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {transactions.map((tx) => (
            <div key={tx.hash} className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ color: tx.status === 'confirmed' ? 'var(--accent-green)' : 'var(--accent)', fontWeight: '600', fontSize: '14px' }}>
                  {tx.status === 'confirmed' ? '✅ Confirmed' : '❌ Failed'}
                </span>
                <span style={{ color: 'var(--text-secondary)', fontSize: '13px' }}>{new Date(tx.timestamp).toLocaleDateString()}</span>
              </div>
              <p style={{ fontWeight: '600', marginBottom: '4px' }}>{tx.amount} {tx.symbol}</p>
              <p style={{ color: 'var(--text-secondary)', fontSize: '12px', wordBreak: 'break-all' }}>To: {tx.to}</p>
              <p style={{ color: 'var(--text-secondary)', fontSize: '11px', wordBreak: 'break-all', marginTop: '4px' }}>{tx.hash.slice(0, 20)}...</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
