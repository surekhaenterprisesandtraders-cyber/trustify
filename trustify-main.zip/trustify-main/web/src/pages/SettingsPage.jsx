import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ethers } from 'ethers';
import { useWalletStore } from '../store/walletStore';

export default function SettingsPage() {
  const navigate = useNavigate();
  const { encryptedMnemonic, wallets, resetWallet } = useWalletStore();
  const [pin, setPin] = useState('');
  const [verified, setVerified] = useState(false);

  const verifyPin = async () => {
    try {
      await ethers.Wallet.fromEncryptedJson(encryptedMnemonic, pin);
      setVerified(true);
    } catch (e) { alert('Wrong PIN'); }
  };

  const handleReset = () => {
    if (window.confirm('Are you sure? This will delete your wallet from this device!')) {
      resetWallet();
      navigate('/');
    }
  };

  return (
    <div className="container" style={{ paddingTop: '40px' }}>
      <button onClick={() => navigate('/dashboard')} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer', marginBottom: '24px', fontSize: '16px' }}>← Back</button>
      <h2 style={{ marginBottom: '24px' }}>Settings</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div className="card">
          <h3 style={{ marginBottom: '8px' }}>Wallet Address</h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '13px', wordBreak: 'break-all' }}>{wallets.ethereum}</p>
        </div>
        <div className="card">
          <h3 style={{ marginBottom: '12px' }}>Verify PIN</h3>
          <input type="password" placeholder="Enter PIN" value={pin} onChange={(e) => setPin(e.target.value)} style={{ marginBottom: '12px' }} />
          <button className="btn btn-secondary" onClick={verifyPin}>Verify PIN</button>
          {verified && <p style={{ marginTop: '12px', color: 'var(--accent-green)', fontSize: '13px' }}>✅ PIN verified successfully</p>}
        </div>
        <button className="btn" onClick={handleReset}
          style={{ background: 'rgba(233, 69, 96, 0.2)', color: 'var(--accent)', border: '1px solid var(--accent)' }}>
          🗑️ Reset Wallet
        </button>
      </div>
    </div>
  );
}
