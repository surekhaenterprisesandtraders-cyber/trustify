import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import * as bip39 from 'bip39';
import { ethers } from 'ethers';
import { useWalletStore } from '../store/walletStore';

export default function ImportWalletPage() {
  const navigate = useNavigate();
  const { setWallet } = useWalletStore();
  const [mnemonicInput, setMnemonicInput] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [loading, setLoading] = useState(false);

  const handleImport = async () => {
    const trimmed = mnemonicInput.trim().toLowerCase();
    if (!bip39.validateMnemonic(trimmed)) return alert('Invalid seed phrase');
    if (pin.length < 6) return alert('PIN must be at least 6 digits');
    if (pin !== confirmPin) return alert('PINs do not match');
    setLoading(true);
    try {
      const hdNode = ethers.HDNodeWallet.fromPhrase(trimmed);
      const ethWallet = hdNode.derivePath("m/44'/60'/0'/0/0");
      const tempWallet = new ethers.Wallet(ethWallet.privateKey);
      const encryptedMnemonic = await tempWallet.encrypt(pin);
      setWallet({ ethereum: ethWallet.address, bsc: ethWallet.address }, encryptedMnemonic);
      navigate('/dashboard');
    } catch (e) { alert('Error: ' + e.message); }
    setLoading(false);
  };

  return (
    <div className="container" style={{ paddingTop: '40px' }}>
      <button onClick={() => navigate('/')}
        style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer', marginBottom: '24px', fontSize: '16px' }}>
        ← Back
      </button>
      <h2 style={{ marginBottom: '8px' }}>Import Wallet</h2>
      <p style={{ color: 'var(--text-secondary)', marginBottom: '24px', fontSize: '14px' }}>Enter your 12-word seed phrase to restore your wallet.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <textarea placeholder="Enter your 12-word seed phrase..." value={mnemonicInput} onChange={(e) => setMnemonicInput(e.target.value)} rows={4}
          style={{ width: '100%', padding: '12px 16px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '10px', color: 'var(--text-primary)', fontSize: '16px', resize: 'none' }} />
        <input type="password" placeholder="Set PIN (min 6 digits)" value={pin} onChange={(e) => setPin(e.target.value)} maxLength={12} />
        <input type="password" placeholder="Confirm PIN" value={confirmPin} onChange={(e) => setConfirmPin(e.target.value)} maxLength={12} />
        <button className="btn btn-primary" onClick={handleImport} disabled={loading}>
          {loading ? 'Importing...' : 'Import Wallet'}
        </button>
      </div>
    </div>
  );
}
