import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { useWalletStore } from '../store/walletStore';

export default function ReceivePage() {
  const navigate = useNavigate();
  const { wallets } = useWalletStore();
  const [network, setNetwork] = useState('ethereum');
  const [copied, setCopied] = useState(false);
  const address = wallets[network] || wallets.ethereum || '';

  const copyAddress = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="container" style={{ paddingTop: '40px' }}>
      <button onClick={() => navigate('/dashboard')} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer', marginBottom: '24px', fontSize: '16px' }}>← Back</button>
      <h2 style={{ marginBottom: '24px' }}>Receive Crypto</h2>
      <select value={network} onChange={(e) => setNetwork(e.target.value)}
        style={{ width: '100%', padding: '12px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '10px', color: 'var(--text-primary)', fontSize: '16px', marginBottom: '24px' }}>
        <option value="ethereum">Ethereum (ERC20)</option>
        <option value="bsc">BSC (BEP20)</option>
        <option value="tron">Tron (TRC20)</option>
      </select>
      <div className="card" style={{ textAlign: 'center' }}>
        <div style={{ display: 'inline-block', padding: '16px', background: 'white', borderRadius: '12px', marginBottom: '16px' }}>
          <QRCodeSVG value={address} size={200} />
        </div>
        <p style={{ fontSize: '13px', wordBreak: 'break-all', color: 'var(--text-secondary)', marginBottom: '16px' }}>{address}</p>
        <button className="btn btn-primary" onClick={copyAddress}>{copied ? '✅ Copied!' : '📋 Copy Address'}</button>
      </div>
      <p style={{ marginTop: '16px', color: 'var(--accent)', fontSize: '13px', textAlign: 'center' }}>
        ⚠️ Only send {network === 'tron' ? 'TRC20' : network === 'bsc' ? 'BEP20' : 'ERC20'} tokens to this address
      </p>
    </div>
  );
}
