import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useWalletStore } from '../store/walletStore';

export default function OnboardingPage() {
  const navigate = useNavigate();
  const { isWalletCreated } = useWalletStore();

  React.useEffect(() => {
    if (isWalletCreated) navigate('/dashboard');
  }, [isWalletCreated, navigate]);

  return (
    <div className="container" style={{ paddingTop: '80px', textAlign: 'center' }}>
      <div style={{ marginBottom: '40px' }}>
        <div style={{ fontSize: '64px', marginBottom: '16px' }}>🔐</div>
        <h1 style={{ fontSize: '32px', fontWeight: '700', marginBottom: '8px' }}>Trustify</h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '16px' }}>Your non-custodial crypto wallet</p>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <button className="btn btn-primary" onClick={() => navigate('/create')}>Create New Wallet</button>
        <button className="btn btn-secondary" onClick={() => navigate('/import')}>Import Existing Wallet</button>
      </div>
      <p style={{ marginTop: '32px', color: 'var(--text-secondary)', fontSize: '13px' }}>
        🔒 Your keys, your crypto. We never store your private keys.
      </p>
    </div>
  );
}
