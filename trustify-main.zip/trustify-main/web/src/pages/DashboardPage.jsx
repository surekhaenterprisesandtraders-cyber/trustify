import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { ethers } from 'ethers';
import { useWalletStore } from '../store/walletStore';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000';
const RPC_URLS = { ethereum: 'https://eth.llamarpc.com', bsc: 'https://bsc-dataseed.binance.org' };
const USDT_ERC20 = '0xdAC17F958D2ee523a2206206994597C13D831ec7';
const ERC20_ABI = ['function balanceOf(address owner) view returns (uint256)', 'function decimals() view returns (uint8)'];

export default function DashboardPage() {
  const navigate = useNavigate();
  const { wallets, balances, prices, setBalances, setPrices } = useWalletStore();
  const [loading, setLoading] = useState(true);
  const [totalUSD, setTotalUSD] = useState('0.00');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(`${API_BASE}/api/prices`);
      if (data.success) setPrices(data.prices);
      const provider = new ethers.JsonRpcProvider(RPC_URLS.ethereum);
      const ethBal = await provider.getBalance(wallets.ethereum);
      const ethBalance = parseFloat(ethers.formatEther(ethBal)).toFixed(4);
      const contract = new ethers.Contract(USDT_ERC20, ERC20_ABI, provider);
      const [usdtBal, dec] = await Promise.all([contract.balanceOf(wallets.ethereum), contract.decimals()]);
      const usdtBalance = parseFloat(ethers.formatUnits(usdtBal, dec)).toFixed(2);
      const newBalances = { ETH: ethBalance, USDT: usdtBalance, BNB: '0.0000', TRX: '0.000000' };
      setBalances(newBalances);
      const p = data.prices || {};
      setTotalUSD((parseFloat(ethBalance) * (p.ETH?.usd || 0) + parseFloat(usdtBalance)).toFixed(2));
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const coins = [
    { symbol: 'ETH', name: 'Ethereum', icon: '⟠', network: 'ERC20' },
    { symbol: 'BNB', name: 'BNB', icon: '🔶', network: 'BEP20' },
    { symbol: 'TRX', name: 'Tron', icon: '🔴', network: 'TRC20' },
    { symbol: 'USDT', name: 'Tether USD', icon: '💵', network: 'Multi' },
  ];

  return (
    <div className="container" style={{ paddingTop: '24px', paddingBottom: '100px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <h2>Trustify</h2>
        <button onClick={() => navigate('/settings')} style={{ background: 'none', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer', fontSize: '24px' }}>⚙️</button>
      </div>
      <div className="card" style={{ textAlign: 'center', marginBottom: '24px', background: 'linear-gradient(135deg, #0f3460, #16213e)' }}>
        <p style={{ color: 'var(--text-secondary)', marginBottom: '8px' }}>Total Balance</p>
        <h1 style={{ fontSize: '36px', fontWeight: '700' }}>{loading ? '...' : `$${totalUSD}`}</h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '13px', marginTop: '8px' }}>
          {wallets.ethereum ? `${wallets.ethereum.slice(0, 6)}...${wallets.ethereum.slice(-4)}` : ''}
        </p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px', marginBottom: '24px' }}>
        {[{ label: 'Send', icon: '↑', path: '/send' }, { label: 'Receive', icon: '↓', path: '/receive' }, { label: 'History', icon: '📋', path: '/transactions' }].map((a) => (
          <button key={a.label} className="btn btn-secondary" onClick={() => navigate(a.path)} style={{ flexDirection: 'column', gap: '4px', padding: '16px 8px' }}>
            <span style={{ fontSize: '24px' }}>{a.icon}</span>
            <span style={{ fontSize: '13px' }}>{a.label}</span>
          </button>
        ))}
      </div>
      <h3 style={{ marginBottom: '16px', color: 'var(--text-secondary)' }}>Assets</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {coins.map((coin) => (
          <div key={coin.symbol} className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span style={{ fontSize: '32px' }}>{coin.icon}</span>
              <div>
                <p style={{ fontWeight: '600' }}>{coin.symbol}</p>
                <p style={{ color: 'var(--text-secondary)', fontSize: '13px' }}>{coin.network}</p>
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <p style={{ fontWeight: '600' }}>{loading ? '...' : (balances[coin.symbol] || '0.00')}</p>
              <p style={{ color: 'var(--text-secondary)', fontSize: '13px' }}>
                ${prices[coin.symbol] ? (parseFloat(balances[coin.symbol] || 0) * prices[coin.symbol].usd).toFixed(2) : '0.00'}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
