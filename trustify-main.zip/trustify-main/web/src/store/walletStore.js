import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useWalletStore = create(
  persist(
    (set, get) => ({
      isWalletCreated: false,
      encryptedMnemonic: null,
      wallets: {},
      balances: {},
      prices: {},
      transactions: [],
      activeNetwork: 'ethereum',

      setWallet: (wallets, encryptedMnemonic) =>
        set({ wallets, encryptedMnemonic, isWalletCreated: true }),

      setBalances: (balances) => set({ balances }),
      setPrices: (prices) => set({ prices }),
      setTransactions: (transactions) => set({ transactions }),
      setActiveNetwork: (network) => set({ activeNetwork: network }),

      resetWallet: () =>
        set({
          isWalletCreated: false,
          encryptedMnemonic: null,
          wallets: {},
          balances: {},
          transactions: [],
        }),
    }),
    { name: 'trustify-wallet' }
  )
);
