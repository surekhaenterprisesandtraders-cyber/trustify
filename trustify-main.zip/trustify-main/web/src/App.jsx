import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useWalletStore } from './store/walletStore';
import OnboardingPage from './pages/OnboardingPage';
import CreateWalletPage from './pages/CreateWalletPage';
import ImportWalletPage from './pages/ImportWalletPage';
import DashboardPage from './pages/DashboardPage';
import SendPage from './pages/SendPage';
import ReceivePage from './pages/ReceivePage';
import TransactionsPage from './pages/TransactionsPage';
import SettingsPage from './pages/SettingsPage';

function PrivateRoute({ children }) {
  const { isWalletCreated } = useWalletStore();
  return isWalletCreated ? children : <Navigate to="/" replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<OnboardingPage />} />
      <Route path="/create" element={<CreateWalletPage />} />
      <Route path="/import" element={<ImportWalletPage />} />
      <Route path="/dashboard" element={<PrivateRoute><DashboardPage /></PrivateRoute>} />
      <Route path="/send" element={<PrivateRoute><SendPage /></PrivateRoute>} />
      <Route path="/receive" element={<PrivateRoute><ReceivePage /></PrivateRoute>} />
      <Route path="/transactions" element={<PrivateRoute><TransactionsPage /></PrivateRoute>} />
      <Route path="/settings" element={<PrivateRoute><SettingsPage /></PrivateRoute>} />
    </Routes>
  );
}
