const express = require('express');
const axios = require('axios');
const router = express.Router();

router.get('/:network/:address', async (req, res) => {
  const { network, address } = req.params;
  try {
    let txList = [];
    if (network === 'ethereum') {
      const apiKey = process.env.ETHERSCAN_API_KEY || '';
      const { data } = await axios.get(
        `https://api.etherscan.io/api?module=account&action=txlist&address=${address}&sort=desc&apikey=${apiKey}`
      );
      txList = (data.result || []).slice(0, 20).map(formatEthTx);
    } else if (network === 'bsc') {
      const apiKey = process.env.BSCSCAN_API_KEY || '';
      const { data } = await axios.get(
        `https://api.bscscan.com/api?module=account&action=txlist&address=${address}&sort=desc&apikey=${apiKey}`
      );
      txList = (data.result || []).slice(0, 20).map(formatEthTx);
    } else if (network === 'tron') {
      const { data } = await axios.get(
        `https://api.trongrid.io/v1/accounts/${address}/transactions?limit=20`
      );
      txList = (data.data || []).map(formatTronTx);
    }
    res.json({ success: true, transactions: txList });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch transactions' });
  }
});

function formatEthTx(tx) {
  return {
    hash: tx.hash,
    from: tx.from,
    to: tx.to,
    amount: (parseInt(tx.value) / 1e18).toFixed(6),
    symbol: 'ETH',
    timestamp: parseInt(tx.timeStamp) * 1000,
    status: tx.isError === '0' ? 'confirmed' : 'failed',
  };
}

function formatTronTx(tx) {
  const contract = tx.raw_data?.contract?.[0];
  const value = contract?.parameter?.value;
  return {
    hash: tx.txID,
    from: value?.owner_address || '',
    to: value?.to_address || '',
    amount: ((value?.amount || 0) / 1_000_000).toFixed(6),
    symbol: 'TRX',
    timestamp: tx.block_timestamp,
    status: tx.ret?.[0]?.contractRet === 'SUCCESS' ? 'confirmed' : 'failed',
  };
}

module.exports = router;
