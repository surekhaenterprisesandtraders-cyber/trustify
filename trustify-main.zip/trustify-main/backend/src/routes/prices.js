const express = require('express');
const axios = require('axios');
const router = express.Router();

const COINGECKO_IDS = {
  BTC: 'bitcoin',
  ETH: 'ethereum',
  BNB: 'binancecoin',
  TRX: 'tron',
  USDT: 'tether',
};

router.get('/', async (req, res) => {
  try {
    const ids = Object.values(COINGECKO_IDS).join(',');
    const { data } = await axios.get(
      `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true`
    );
    const prices = {};
    for (const [symbol, id] of Object.entries(COINGECKO_IDS)) {
      prices[symbol] = {
        usd: data[id]?.usd || 0,
        change24h: data[id]?.usd_24h_change || 0,
      };
    }
    res.json({ success: true, prices });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch prices' });
  }
});

module.exports = router;
