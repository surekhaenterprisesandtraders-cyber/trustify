# Trustify - Crypto Wallet

A non-custodial crypto wallet supporting BTC, ETH, BNB, TRX and USDT (ERC20/BEP20/TRC20).

## Features
- Multi-coin support (BTC, ETH, BNB, TRX, USDT)
- Non-custodial (private keys stay on device)
- QR Code Scanner
- Send / Receive crypto
- Transaction history
- Live price feed
- Web PWA + Android APK

## Networks Supported
- Ethereum (ERC20)
- Binance Smart Chain (BEP20)
- Tron (TRC20)

## Tech Stack
| Part | Technology |
|------|------------|
| Web (PWA) | React.js + Vite |
| Mobile APK | React Native (Expo) |
| Shared Logic | TypeScript library |
| Backend | Node.js + Express |
| Blockchain | ethers.js + tronweb |

## Project Structure
```
trustify/
├── backend/       # Node.js API (price feed, tx broadcast)
├── web/           # React.js PWA
├── mobile/        # React Native Expo APK
├── shared/        # Common wallet logic (keys, balance, tx)
└── README.md
```

## Getting Started

### Prerequisites
- Node.js >= 18
- npm or yarn
- Expo CLI (for mobile)

### Installation
```bash
# Backend
cd backend && npm install && npm run dev

# Web
cd web && npm install && npm run dev

# Mobile
cd mobile && npm install && npx expo start
```

## Security
- Private keys are never sent to the server
- Seed phrase encrypted with user PIN on device
- All blockchain calls made directly from client
